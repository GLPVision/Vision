package data;

/**
 * Classe Heure
 * @author Christian BERANGER, Alexis MOSQUERA, Antoine QIU
 * @version 2
 */
public class Heure {
    /**
     * Heure
     */
    private String heure;
    /**
     * Minute
     */
    private String minute;
    /**
     * Seconde
     */
    private String seconde;
    /**
     * Constructeur, initialise les variables
     * @param heure Heure
     * @param minute Minute
     * @param seconde Seconde
     */
    public Heure(String heure, String minute, String seconde){
        this.heure = heure;
        this.minute = minute;
        this.seconde = seconde;
    }
    /**
     * Fonction qui retourne l'heure
     * @return Heure
     */
    public String getHeure(){
        return heure;
    }
    /**
     * Fonction qui retourne les minutes
     * @return Minute
     */
    public String getMinute(){
        return minute;
    }
    /**
     * Fonction qui retourne les secondes
     * @return Seconde
     */
    public String getSeconde(){
        return seconde;
    }
}
